from .index import FileIndex

__all__ = ["FileIndex"]
