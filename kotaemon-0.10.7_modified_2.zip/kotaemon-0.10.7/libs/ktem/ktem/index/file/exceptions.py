from ktem.exceptions import KHException


class FileExistsError(KHException):
    pass
