SUPPORTED_LANGUAGE_MAP = {
    "en": "English",
    "vi": "Vietnamese",
    }
