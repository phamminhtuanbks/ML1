# Changelogs

## v0.0.1

- Chat: interact with chatbot with simple pipeline, rewoo and react agents
- Chat: conversation management: create, delete, rename conversations
- Files: upload files
- Files: select files as context for chatbot
- User management: create, sign-in, sign-out, change password
- Setting: common settings and pipeline-based settings
- Info panel: show Cinnamon AI and Kotaemon information
