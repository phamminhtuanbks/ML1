## Chat

The kotaemon focuses on question and answering over a corpus of data. Below
is the gentle introduction about the chat functionality.

- Users can upload corpus of files.
- Users can converse to the chatbot to ask questions about the corpus of files.
- Users can view the reference in the files.
