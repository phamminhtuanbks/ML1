{%
    include-markdown "../../README.md"
    start="<!-- start-intro -->"
    end="<!-- end-intro -->"
%}
